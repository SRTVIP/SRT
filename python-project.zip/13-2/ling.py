import pygame

from settings import Settings
from pygame.sprite import Group
import fulfill as f

def bling():
    pygame.init() # 初始化

    sets = Settings() # 获取设置
    screen = pygame.display.set_mode((sets.screen_width, sets.screen_height)) # 获取屏幕
    pygame.display.set_caption("stars") # 标题

    stars = Group()
    f.create_group(screen, sets, stars)

    while True:
        f.check_quit() #检测退出
        f.update_screen(screen, sets, stars) #刷新屏幕

bling()