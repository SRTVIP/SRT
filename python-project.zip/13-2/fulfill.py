import sys
import pygame
from star import Star
from random import randint

def check_quit():
    for event in pygame.event.get():  # 获取鼠标键盘操作
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q:
                sys.exit()

def update_screen(screen, sets, stars):
    screen.fill(sets.screen_color)  # 填充屏幕颜色
    stars.draw(screen)
    pygame.display.flip()  # 使屏幕可见

def create_group(screen, sets, stars):
    star = Star(screen, sets)
    star_width = star.rect.width
    star_height = star.rect.height
    number_x = int(sets.screen_width / 3 / star_width)
    number_y = int(sets.screen_height / 2 / star_height)
    for y in range(number_y):
        for x in range(number_x):
            star = Star(screen, sets)
            p = randint(-10,10)
            star.x = (3*x+1) * star_width + p
            star.y = (2*y+1) * star_height + p
            star.rect.x = star.x
            star.rect.y = star.y
            stars.add(star)