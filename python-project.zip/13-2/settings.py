import pygame

class Settings():
    def __init__(self):

        self.screen_width = 1200
        self.screen_height = 800
        self.screen_color = (230, 230, 230) 

        self.star_image = pygame.image.load('images/star.bmp')