from pygame.sprite import Sprite # 精灵类

class Star(Sprite):
    def __init__(self, screen, sets):
        super(Star, self).__init__()
        self.sets = sets
        self.screen = screen
        self.image = sets.star_image
        self.rect = self.image.get_rect()
        self.screen_rect = screen.get_rect()

        self.rect.x = self.rect.width
        self.rect.y = self.rect.height
        self.x = float(self.rect.x)

    def print_star(self):
        self.screen.blit(self.image, self.rect)